import numpy as np
from flask import Flask, request, jsonify, render_template
from joblib import load
from tensorflow.keras.models import load_model

app = Flask(__name__)

model = load_model("fishModel.h5")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/result',methods=['POST'])
def fish_predict():
    
    weight = request.form['weight']
    length1 = request.form['length1']
    length2 = request.form['length2']
    length3 = request.form['length3']
    height = request.form['height']
    width = request.form['width']
    
    total = [[float(weight), float(length1), float(length2), float(length3), float(height), float(width)]]
    preds = model.predict(total)    
    
    species = ['Bream', 'Parrki', 'Perch', 'Pike', 'Roach', 'Smelt', 'Whitefish']
    
    text = species[np.argmax(preds)]
    
    return render_template('result.html', result ='Result: {}'.format(text))

if __name__ == "__main__":
    app.run(debug=True)
