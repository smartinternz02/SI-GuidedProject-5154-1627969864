console.log('Index.js')

//Handling the modal 
launch_modal = document.getElementById("launch_modal");
close_modal = document.getElementById("close");
modal = document.getElementById("modal-container"); 

launch_modal.addEventListener('click', () => {
    modal.classList.remove('hide');
});

close_modal.addEventListener('click', () => {
    modal.classList.add('hide');
});

